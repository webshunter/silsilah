<HEAD>
<SCRIPT language="JavaScript">
<!--hide

var password;
var pass1="C4PT4IN";

password=prompt('Khask Lpass Azebi :D !!',' ');

if (password==pass1)
  alert('Marhaba :D !!');
else
   {
    window.location="python.php";
    }

//-->
</SCRIPT>
</HEAD><br>
